<footer class="footer-bg ">
	<div class="container">
		<div class="row">
			<div class="col-md-4 text-left">
			 <a class="" href="http://www.asce.org/" target="blank"><img src="<?php echo base_url();?>img/footerlogo.png" /><br>
			       1801 Alexander Bell Drive<br>
				   Reston, VA 20191-4400<br>
				   703-295-6300 | 800-548-2723</a><br>
			</div>
			<div class="col-md-4 text-center">
			<a href="https://asce7hazardtool.online/" target="blank">ASCE 7 Hazard Tool</a><br>
				<a href="http://www.asce.org/asce-7/" target="blank">ASCE 7 Related Products</a><br>
				<a href="<?php echo base_url();?>TermsOfUse" target="blank">Terms of Use</a><br>
				<a href="<?php echo base_url();?>AboutASCE7Online" target="blank">FAQs</a>
			</div>
			<div class="col-md-4 text-center">
				<a href=" http://www.asce.org/about_asce/" target="blank">About ASCE</a><br>
				<a href="http://www.asce.org/contact_us/ " target="blank">Contact Us</a><br>
				<a href="http://ascelibrary.org/" target="blank">ASCE Library</a>
			</div>
			<br>
			<div class="col-md-12 text-center color-white" style="
    margin-top: 5px;">
				© 2018 American Society of Civil Engineers
			</div>
		</div>
	</div>
	
	
	
</footer>
<!--Scripts put here-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

</body>



</html>
