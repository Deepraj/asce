<!-- saved from url=(0057)http://asce.adi-mps.com/asce_service/index.php/auth/login -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Reader</title>
<link href="<?php echo base_url();?>/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo base_url();?>/css/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>/css/style-ie-only.css">
</head>
<body>
<form action="" method="post" accept-charset="utf-8">
	<div id="formControl">
		<div class="header">
         <div class="container">
         <div class="row">
  <div class="col-md-4">
  </div>
  <div class="col-md-4"> 
  <img src="<?php echo base_url();?>/images/Logo_White_145x58.png">
</div>
<div class="col-md-4 text-right">
  </div>
  </div>
 </div>
 </div>
<div class="container">
 <div class="col-md-12">
<div id="login_details">
   <div style="margin-left: 300px;margin-top:200px; "><p style=" font-size:16px; font-weight:600; color:red;">
   Your session will automatically close due to inactivity. Please close your browser and log in again</p>
   </div>
</div>	
</div>
</div>
</div>
</form>	
 </body>
</html>
