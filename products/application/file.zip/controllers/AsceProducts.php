<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class AsceProducts extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/index.php/welcome
	 * - or -
	 * http://example.com/index.php/welcome/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 *
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
		// Construct the parent class
		parent::__construct ();
		$this->load->helper ( array ('form','url','xml','security','directory' ) );
		$this->load->database ();
		$this->load->library(array('email'));
		$this->load->library ( 'session' );
		$this->load->library ( 'encrypt' );
		//$this->load->model ( 'LoginModel' );
		$this->load->model ( 'ProductModel' );
		$this->load->library ( 'template' );
	}

	public function index() {
		
		
		/* --------------------------------User Handling-------------------------------- */
		
		
			
			/* ------------------------------------End-------------------------------------- */
			//$this->session->unset_userdata ( 'MasterCustomerId' );
			//$this->session->unset_userdata ( 'ip' );
			//$this->session->unset_userdata ( 'validlogin' );
			//print_r( $_SESSION);	die;
			$currentIP = $this->input->ip_address ();
			$currentIP = trim ( $currentIP );
			//echo ($this->input->valid_ip($aa)?'Valid':'Not Valid');
			//echo $currentIP; die;
			$url=base_url()."index.php/product";
			$data['ipstatus']  = $this->ProductModel->check_ip ($currentIP);
		//print_r($data['ipstatus'][0]->aui_status); die;
		
			$data ['productList'] = $this->ProductModel->get_book ();
			 if($this->input->post('submit')){ 
                             
                    $recaptchaResponse = trim($this->input->post('g-recaptcha-response'));
                    $secret = $this->config->item('google_secret');

                    $url = "https://www.google.com/recaptcha/api/siteverify?secret=" . $secret . "&response=" . $recaptchaResponse . "&remoteip=" . $currentIP;

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    $output = curl_exec($ch);
                    curl_close($ch);

                    $status = json_decode($output, true);
                    if ($status['success']) {
                         $email= $this->input->post('email');
			  $FirstName= $this->input->post('FirstName');
			  $LastName= $this->input->post('LastName');
			  $Company= $this->input->post('Company');
			  $Numberofsites= $this->input->post('Numberofsites');
			  
			 $to_email='asce7tools@asce.org'; 
			$body="Email: ".$email."<br>FirstName: ".$FirstName."<br>LastName: ".$LastName."<br>Company: ".$Company."<br>Numberofsites: ".$Numberofsites;  
			$this->email->to($to_email);
			//$this->email->from('info@mpstechnologies.com');
                        $this->email->from('ascelibrary@asce.org','ASCE Publications');
			$this->email->subject('Request for Corporate Access Quotes Email');
			$this->email->message($body);
			$this->email->set_mailtype("html");
			$send=$this->email->send();
			$this->email->clear();	  
            $msg1= "<h5><strong>Your request has been submitted.</strong></h5>";
			$this->session->set_flashdata('bulkimportmessage',$msg1);
                    } else {
                        $this->session->set_flashdata('bulkimportmessage', 'Sorry Google Recaptcha Unsuccessful!!');
                    }
	}	
			
			
			
			//print_r($data ['productList']); die;
			$this->template->load ( 'pagetemplate/header', 'ProductList' );
			$this->load->view ( 'AsceDashbord',$data);
			$this->template->load ( 'pagetemplate/footer', 'ProductList' );
		}
			

	
}

?>
